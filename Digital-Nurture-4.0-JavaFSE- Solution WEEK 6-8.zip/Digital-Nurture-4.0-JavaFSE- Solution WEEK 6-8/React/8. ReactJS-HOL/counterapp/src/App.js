import React from 'react';
import CountPeople from './components/CountPeople';
import './App.css';

function App() {
  return (
    <div className="App">
      <CountPeople />
    </div>
  );
}

export default App;