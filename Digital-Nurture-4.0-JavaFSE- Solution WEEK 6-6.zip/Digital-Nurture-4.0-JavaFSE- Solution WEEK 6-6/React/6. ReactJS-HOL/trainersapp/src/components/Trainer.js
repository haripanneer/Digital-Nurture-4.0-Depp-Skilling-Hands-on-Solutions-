export class Trainer {
    constructor(TrainerId, Name, Email, Phone, Technology, Skills) {
        this.TrainerId = TrainerId;
        this.Name = Name;
        this.Email = Email;
        this.Phone = Phone;
        this.Technology = Technology;
        this.Skills = Skills;
    }
}