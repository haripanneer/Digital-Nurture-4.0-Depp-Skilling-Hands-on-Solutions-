export const trainers = [
    {
        TrainerId: 1,
        Name: "John Smith",
        Email: "john.smith@example.com",
        Phone: "555-123-4567",
        Technology: "React",
        Skills: ["React", "Redux", "JavaScript"]
    },
    {
        TrainerId: 2,
        Name: "Sarah Johnson",
        Email: "sarah.j@example.com",
        Phone: "555-987-6543",
        Technology: "Node.js",
        Skills: ["Node.js", "Express", "MongoDB"]
    },
    {
        TrainerId: 3,
        Name: "Mike Williams",
        Email: "mike.w@example.com",
        Phone: "555-456-7890",
        Technology: "Angular",
        Skills: ["Angular", "TypeScript", "RxJS"]
    },
    {
        TrainerId: 4,
        Name: "Emily Davis",
        Email: "emily.d@example.com",
        Phone: "555-789-0123",
        Technology: "Java",
        Skills: ["Java", "Spring Boot", "Hibernate"]
    }
];