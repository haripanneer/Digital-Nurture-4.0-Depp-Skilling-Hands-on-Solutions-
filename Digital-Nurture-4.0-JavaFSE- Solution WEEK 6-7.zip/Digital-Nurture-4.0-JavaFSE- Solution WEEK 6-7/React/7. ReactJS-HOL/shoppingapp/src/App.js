import React from 'react';
import OnlineShopping from './components/OnlineShopping';
import './App.css';

function App() {
  return (
    <div className="App">
      <OnlineShopping />
    </div>
  );
}

export default App;
